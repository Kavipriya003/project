from django.contrib import admin
from .models import Customer, Product, Order, Payment

# Customer admin customization
@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'contact_number', 'address')
    search_fields = ('name', 'email')
    list_filter = ('name',)


# Product admin customization
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'description')
    search_fields = ('name', 'description')


# Order admin customization
@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('customer', 'get_product_name', 'quantity', 'total_amount')
    search_fields = ('customer__name', 'product')  # ✅ product is now a string
    list_filter = ('customer', 'product')  # ✅ still okay since product is a CharField

    @admin.display(description='Product Name')
    def get_product_name(self, obj):
        return obj.product



# Payment admin customization
@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('customer', 'transaction_id', 'amount', 'method')
    search_fields = ('customer__name', 'transaction_id')
    list_filter = ('method', 'customer')
    list_select_related = ('customer',)
