from django.shortcuts import render, redirect, get_object_or_404
from .models import Customer, Order, Payment, Product
from django.contrib import messages

def home(request):
    return render(request, 'home.html')


# Add Customer
def add_customer(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        address = request.POST.get('address')
        email = request.POST.get('email')
        contact = request.POST.get('contact')

        if name and email and contact:
            Customer.objects.create(
                name=name,
                address=address,
                email=email,
                contact_number=contact
            )
            messages.success(request, "Customer added successfully.")
            return redirect('home')
        else:
            messages.error(request, "Please fill all required fields.")

    return render(request, 'add_customer.html')


# Place Order
def place_order(request):
    customers = Customer.objects.all()

    if request.method == 'POST':
        try:
            customer_id = request.POST['customer']
            product = request.POST['product'].strip()
            quantity = int(request.POST['quantity'])
            price = float(request.POST['price'])

            if not product or quantity <= 0 or price <= 0:
                raise ValueError("Invalid input.")

            customer = get_object_or_404(Customer, id=customer_id)

            total_amount = quantity * price

            Order.objects.create(
                customer=customer,
                product=product,
                quantity=quantity,
                total_amount=total_amount
            )
            messages.success(request, "Order placed successfully.")
            return redirect('view_history')

        except (KeyError, ValueError):
            return render(request, 'place_order.html', {
                'customers': customers,
                'error': "Please enter valid data."
            })

    return render(request, 'place_order.html', {
        'customers': customers
    })


    
# Add Payment
def add_payment(request):
    customers = Customer.objects.all()

    if request.method == 'POST':
        customer_id = request.POST.get('customer')
        transaction_id = request.POST.get('transaction_id')
        amount = request.POST.get('amount')
        method = request.POST.get('method')

        if customer_id and transaction_id and amount and method:
            try:
                customer = Customer.objects.get(id=customer_id)
                Payment.objects.create(
                    customer=customer,
                    transaction_id=transaction_id,
                    amount=amount,
                    method=method
                )
                messages.success(request, "Payment added successfully.")
                return redirect('view_history')
            except Customer.DoesNotExist:
                messages.error(request, "Selected customer does not exist.")
        else:
            messages.error(request, "All fields are required.")

        return render(request, 'add_payment.html', {
            'customers': customers,
            'selected_customer': customer_id,
            'transaction_id': transaction_id,
            'amount': amount,
            'method': method
        })

    return render(request, 'add_payment.html', {'customers': customers})


# View All History
def view_history(request):
    customers = Customer.objects.all()
    orders = Order.objects.select_related('customer').all()
    payments = Payment.objects.select_related('customer').all()
    return render(request, 'view_history.html', {
        'customers': customers,
        'orders': orders,
        'payments': payments,
    })


# Search History
def search_history(request):
    results = None

    if request.method == 'GET' and (request.GET.get('customer_name') or request.GET.get('transaction_id')):
        customer_name = request.GET.get('customer_name', '').strip()
        transaction_id = request.GET.get('transaction_id', '').strip()

        # Start with all payments
        payments = Payment.objects.select_related('customer').all()

        # Filter if input is provided
        if customer_name:
            payments = payments.filter(customer__name__icontains=customer_name)
        if transaction_id:
            payments = payments.filter(transaction_id__icontains=transaction_id)

        results = payments

    return render(request, 'search_history.html', {
        'results': results
    })


# ==================== EDIT VIEWS ====================

def edit_customer(request, customer_id):
    customer = get_object_or_404(Customer, id=customer_id)

    if request.method == 'POST':
        customer.name = request.POST.get('name')
        customer.address = request.POST.get('address')
        customer.email = request.POST.get('email')
        customer.contact_number = request.POST.get('contact')
        customer.save()
        messages.success(request, "Customer updated successfully.")
        return redirect('view_history')

    return render(request, 'edit_customer.html', {'customer': customer})

def edit_order(request, order_id):
    order = get_object_or_404(Order, id=order_id)

    if request.method == 'POST':
        try:
            product = request.POST['product'].strip()
            quantity = int(request.POST['quantity'])
            price = float(request.POST['price'])

            if not product or quantity <= 0 or price <= 0:
                raise ValueError("Invalid input.")

            order.product = product
            order.quantity = quantity
            order.total_amount = quantity * price
            order.save()

            messages.success(request, "Order updated successfully.")
            return redirect('view_history')

        except (KeyError, ValueError):
            messages.error(request, "Please enter valid data.")

    return render(request, 'edit_order.html', {
    'order': order,
    'unit_price': order.total_amount / order.quantity if order.quantity else 0
})




def edit_payment(request, payment_id):
    payment = get_object_or_404(Payment, id=payment_id)
    customers = Customer.objects.all()
    payment_methods = ["UPI", "Credit Card", "PayPal", "Bank Transfer", "Cash"]  # ✅ dropdown list

    if request.method == 'POST':
        customer_id = request.POST.get('customer')
        transaction_id = request.POST.get('transaction_id')
        amount_str = request.POST.get('amount')
        method = request.POST.get('method')

        try:
            amount = float(amount_str)
            customer = Customer.objects.get(id=customer_id)

            payment.customer = customer
            payment.transaction_id = transaction_id
            payment.amount = amount
            payment.method = method
            payment.save()

            messages.success(request, "Payment updated successfully.")
            return redirect('view_history')

        except (Customer.DoesNotExist, ValueError):
            messages.error(request, "Invalid data provided.")

    return render(request, 'edit_payment.html', {
        'payment': payment,
        'customers': customers,
        'payment_methods': payment_methods  # ✅ pass to template
    })



# ==================== DELETE VIEWS ====================

def delete_customer(request, customer_id):
    customer = get_object_or_404(Customer, id=customer_id)
    customer.delete()
    messages.success(request, "Customer deleted successfully.")
    return redirect('view_history')


def delete_order(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    order.delete()
    messages.success(request, "Order deleted successfully.")
    return redirect('view_history')


def delete_payment(request, payment_id):
    payment = get_object_or_404(Payment, id=payment_id)
    payment.delete()
    messages.success(request, "Payment deleted successfully.")
    return redirect('view_history')
