from django.db import models
from django.core.validators import MinValueValidator
from decimal import Decimal


# ================== Customer Model ==================
class Customer(models.Model):
    name = models.CharField(max_length=100)
    address = models.TextField()
    email = models.EmailField()
    contact_number = models.CharField(max_length=20, blank=True)

    def __str__(self):
        return self.name


# ================== Product Model ==================
class Product(models.Model):
    name = models.CharField(max_length=255, blank=False, null=False)
    description = models.TextField(blank=True)
    price = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(Decimal('0.01'))],
        blank=False,
        null=False
    )

    def __str__(self):
        return f"{self.name} - ₹{self.price:.2f}"

    class Meta:
        ordering = ['name']
        verbose_name = "Product"
        verbose_name_plural = "Products"



# ================== Order Model ==================
class Order(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, default=1)
    product = models.CharField(max_length=100)  
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def __str__(self):
        return f"Order: {self.customer.name} - {self.product} x {self.quantity}"



# ================== Payment Model ==================
PAYMENT_METHOD_CHOICES = [
    ('UPI', 'UPI'),
    ('Credit Card', 'Credit Card'),
    ('PayPal', 'PayPal'),
    ('Bank Transfer', 'Bank Transfer'),
    ('Cash', 'Cash'),
]

class Payment(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    transaction_id = models.CharField(max_length=255, unique=True, blank=False, null=False)
    amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(Decimal('0.01'))],
        blank=False,
        null=False
    )
    method = models.CharField(max_length=50, choices=PAYMENT_METHOD_CHOICES, blank=False, null=False)

    def __str__(self):
        return f"Payment: {self.transaction_id} ({self.customer.name}) - ₹{self.amount:.2f}"

    class Meta:
        ordering = ['-id']
        verbose_name = "Payment"
        verbose_name_plural = "Payments"
